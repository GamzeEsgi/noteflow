/**
 * Auth Routes
 * Kullanıcı kayıt ve giriş işlemleri
 */

const express = require('express');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const { auth } = require('../middleware/auth');

const router = express.Router();

/**
 * POST /api/auth/register
 * Yeni kullanıcı kaydı
 */
router.post('/register', async (req, res) => {
  try {
    const { ad, soyad, email, sifre, blok, kat, daireNo, rol } = req.body;

    // Validasyon
    if (!ad || !soyad || !email || !sifre || !blok || !kat || !daireNo) {
      return res.status(400).json({ mesaj: 'Tüm alanlar zorunludur.' });
    }

    // Email kontrolü
    const existingUser = await User.findOne({ email });
    if (existingUser) {
      return res.status(400).json({ mesaj: 'Bu email zaten kullanılıyor.' });
    }

    // Yeni kullanıcı oluştur (rol sadece admin tarafından set edilebilir, default: user)
    const user = new User({
      ad,
      soyad,
      email,
      sifre,
      blok,
      kat,
      daireNo,
      rol: rol || 'user'
    });

    await user.save();

    // JWT token oluştur
    const token = jwt.sign(
      { userId: user._id, rol: user.rol },
      process.env.JWT_SECRET || 'gizli_anahtar',
      { expiresIn: '7d' }
    );

    res.status(201).json({
      mesaj: 'Kayıt başarılı',
      token,
      kullanici: {
        id: user._id,
        ad: user.ad,
        soyad: user.soyad,
        email: user.email,
        rol: user.rol,
        blok: user.blok,
        kat: user.kat,
        daireNo: user.daireNo
      }
    });
  } catch (error) {
    console.error('Kayıt hatası:', error);
    res.status(500).json({ mesaj: 'Kayıt sırasında bir hata oluştu.', hata: error.message });
  }
});

/**
 * POST /api/auth/login
 * Kullanıcı girişi
 */
router.post('/login', async (req, res) => {
  try {
    const { email, sifre } = req.body;

    // Validasyon
    if (!email || !sifre) {
      return res.status(400).json({ mesaj: 'Email ve şifre gereklidir.' });
    }

    // Kullanıcıyı bul
    const user = await User.findOne({ email });
    if (!user) {
      return res.status(401).json({ mesaj: 'Email veya şifre hatalı.' });
    }

    // Şifre kontrolü
    const isMatch = await user.comparePassword(sifre);
    if (!isMatch) {
      return res.status(401).json({ mesaj: 'Email veya şifre hatalı.' });
    }

    // JWT token oluştur
    const token = jwt.sign(
      { userId: user._id, rol: user.rol },
      process.env.JWT_SECRET || 'gizli_anahtar',
      { expiresIn: '7d' }
    );

    res.json({
      mesaj: 'Giriş başarılı',
      token,
      kullanici: {
        id: user._id,
        ad: user.ad,
        soyad: user.soyad,
        email: user.email,
        rol: user.rol,
        blok: user.blok,
        kat: user.kat,
        daireNo: user.daireNo
      }
    });
  } catch (error) {
    console.error('Giriş hatası:', error);
    res.status(500).json({ mesaj: 'Giriş sırasında bir hata oluştu.', hata: error.message });
  }
});

/**
 * GET /api/auth/me
 * Giriş yapmış kullanıcının bilgilerini getir
 */
router.get('/me', auth, async (req, res) => {
  try {
    res.json({
      kullanici: {
        id: req.user._id,
        ad: req.user.ad,
        soyad: req.user.soyad,
        email: req.user.email,
        rol: req.user.rol,
        blok: req.user.blok,
        kat: req.user.kat,
        daireNo: req.user.daireNo
      }
    });
  } catch (error) {
    res.status(500).json({ mesaj: 'Bir hata oluştu.', hata: error.message });
  }
});

module.exports = router;

