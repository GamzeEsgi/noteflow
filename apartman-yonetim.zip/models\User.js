/**
 * User Model
 * Kullanıcı, Yönetici ve Personel bilgilerini tutar
 */

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  ad: {
    type: String,
    required: true,
    trim: true
  },
  soyad: {
    type: String,
    required: true,
    trim: true
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true,
    trim: true
  },
  sifre: {
    type: String,
    required: true,
    minlength: 6
  },
  rol: {
    type: String,
    enum: ['user', 'admin', 'personel'],
    default: 'user'
  },
  blok: {
    type: String,
    required: true,
    trim: true
  },
  kat: {
    type: String,
    required: true,
    trim: true
  },
  daireNo: {
    type: String,
    required: true,
    trim: true
  }
}, {
  timestamps: true
});

// Şifreyi hash'le (kayıt öncesi)
userSchema.pre('save', async function(next) {
  if (!this.isModified('sifre')) return next();
  
  try {
    const salt = await bcrypt.genSalt(10);
    this.sifre = await bcrypt.hash(this.sifre, salt);
    next();
  } catch (error) {
    next(error);
  }
});

// Şifre karşılaştırma metodu
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.sifre);
};

module.exports = mongoose.model('User', userSchema);

