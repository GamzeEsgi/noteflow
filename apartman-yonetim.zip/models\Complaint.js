/**
 * Complaint Model
 * Şikayet bilgilerini tutar
 */

const mongoose = require('mongoose');

const complaintSchema = new mongoose.Schema({
  kullaniciId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  aciklama: {
    type: String,
    required: true,
    trim: true
  },
  durum: {
    type: String,
    enum: ['Oluşturuldu', 'Yöneticiye iletildi', 'Personele atandı', 'Çözülüyor', 'Tamamlandı'],
    default: 'Oluşturuldu'
  },
  personelId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    default: null
  }
}, {
  timestamps: true
});

// Kullanıcı bilgilerini populate etmek için
complaintSchema.virtual('kullanici', {
  ref: 'User',
  localField: 'kullaniciId',
  foreignField: '_id',
  justOne: true
});

// Personel bilgilerini populate etmek için
complaintSchema.virtual('personel', {
  ref: 'User',
  localField: 'personelId',
  foreignField: '_id',
  justOne: true
});

// Virtual'ları JSON'a dahil et
complaintSchema.set('toJSON', { virtuals: true });

module.exports = mongoose.model('Complaint', complaintSchema);

