/**
 * Apartman Yönetim Sistemi - Ana JavaScript Dosyası
 * Vanilla JavaScript SPA (Single Page Application)
 */

// API Base URL - Production'da otomatik algılama
const API_URL = (() => {
  // Vercel production'da
  if (window.location.hostname.includes('vercel.app') || window.location.hostname.includes('vercel.com')) {
    return '/api';
  }
  // Local development
  return 'http://localhost:5000/api';
})();

// Global State
let currentUser = null;
let currentRole = null;

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', () => {
    checkAuth();
    setupEventListeners();
});

/**
 * Authentication Kontrolü
 */
function checkAuth() {
    const token = localStorage.getItem('token');
    const user = JSON.parse(localStorage.getItem('user') || 'null');
    
    if (token && user) {
        currentUser = user;
        currentRole = user.rol;
        showPanel(user.rol);
    } else {
        showPage('login-page');
    }
}

/**
 * Event Listeners
 */
function setupEventListeners() {
    // Giriş formu
    document.getElementById('login-form').addEventListener('submit', handleLogin);
    
    // Tab butonları (giriş sayfası)
    document.querySelectorAll('.auth-tabs .tab-btn').forEach(btn => {
        btn.addEventListener('click', (e) => {
            document.querySelectorAll('.auth-tabs .tab-btn').forEach(b => b.classList.remove('active'));
            e.target.classList.add('active');
        });
    });

    // Şikayet oluştur formu
    document.getElementById('complaint-form').addEventListener('submit', handleCreateComplaint);
}

/**
 * Giriş İşlemi
 */
async function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('login-email').value;
    const password = document.getElementById('login-password').value;
    const errorDiv = document.getElementById('login-error');
    
    errorDiv.textContent = '';
    errorDiv.classList.remove('show');

    try {
        const response = await fetch(`${API_URL}/auth/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email, sifre: password })
        });

        const data = await response.json();

        if (response.ok) {
            // Token ve kullanıcı bilgilerini kaydet
            localStorage.setItem('token', data.token);
            localStorage.setItem('user', JSON.stringify(data.kullanici));
            
            currentUser = data.kullanici;
            currentRole = data.kullanici.rol;
            
            showPanel(data.kullanici.rol);
        } else {
            errorDiv.textContent = data.mesaj || 'Giriş başarısız';
            errorDiv.classList.add('show');
        }
    } catch (error) {
        errorDiv.textContent = 'Sunucuya bağlanılamadı. Lütfen daha sonra tekrar deneyin.';
        errorDiv.classList.add('show');
        console.error('Login error:', error);
    }
}

/**
 * Çıkış İşlemi
 */
function logout() {
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    currentUser = null;
    currentRole = null;
    showPage('login-page');
    document.getElementById('login-form').reset();
}

/**
 * Panel Göster
 */
function showPanel(rol) {
    if (rol === 'user') {
        showPage('user-panel');
        document.getElementById('user-name').textContent = `${currentUser.ad} ${currentUser.soyad}`;
        loadUserComplaints();
    } else if (rol === 'admin') {
        showPage('admin-panel');
        loadAdminComplaints();
        loadUsers();
    } else if (rol === 'personel') {
        showPage('personel-panel');
        loadPersonelComplaints();
    }
}

/**
 * Sayfa Göster
 */
function showPage(pageId) {
    document.querySelectorAll('.page').forEach(page => {
        page.classList.remove('active');
    });
    document.getElementById(pageId).classList.add('active');
}

/**
 * Kullanıcı Tab Değiştir
 */
function showUserTab(tab) {
    document.querySelectorAll('#user-panel .tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('#user-panel .tab-content').forEach(content => content.classList.remove('active'));
    
    if (tab === 'create') {
        document.querySelector('#user-panel .tab-btn:first-child').classList.add('active');
        document.getElementById('user-create-tab').classList.add('active');
    } else {
        document.querySelector('#user-panel .tab-btn:last-child').classList.add('active');
        document.getElementById('user-list-tab').classList.add('active');
        loadUserComplaints();
    }
}

/**
 * Admin Tab Değiştir
 */
function showAdminTab(tab) {
    document.querySelectorAll('.nav-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    if (tab === 'complaints') {
        document.querySelector('.nav-btn:first-child').classList.add('active');
        document.getElementById('admin-complaints-tab').classList.add('active');
        document.getElementById('admin-page-title').textContent = 'Tüm Şikayetler';
        loadAdminComplaints();
    } else {
        document.querySelectorAll('.nav-btn')[1].classList.add('active');
        document.getElementById('admin-users-tab').classList.add('active');
        document.getElementById('admin-page-title').textContent = 'Kullanıcılar';
        loadUsers();
    }
}

/**
 * Şikayet Oluştur
 */
async function handleCreateComplaint(e) {
    e.preventDefault();
    
    const aciklama = document.getElementById('complaint-text').value;
    const successDiv = document.getElementById('complaint-success');
    const errorDiv = document.getElementById('complaint-error');
    
    successDiv.textContent = '';
    successDiv.classList.remove('show');
    errorDiv.textContent = '';
    errorDiv.classList.remove('show');

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/complaints`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ aciklama })
        });

        const data = await response.json();

        if (response.ok) {
            successDiv.textContent = 'Şikayet başarıyla oluşturuldu!';
            successDiv.classList.add('show');
            document.getElementById('complaint-form').reset();
            
            // Şikayetler listesini yenile
            setTimeout(() => {
                showUserTab('list');
            }, 1500);
        } else {
            errorDiv.textContent = data.mesaj || 'Şikayet oluşturulamadı';
            errorDiv.classList.add('show');
        }
    } catch (error) {
        errorDiv.textContent = 'Sunucuya bağlanılamadı.';
        errorDiv.classList.add('show');
        console.error('Create complaint error:', error);
    }
}

/**
 * Kullanıcı Şikayetlerini Yükle
 */
async function loadUserComplaints() {
    const listDiv = document.getElementById('user-complaints-list');
    listDiv.innerHTML = '<div class="loading">Yükleniyor...</div>';

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/complaints/my`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            if (data.sikayetler.length === 0) {
                listDiv.innerHTML = '<div class="empty-state"><p>Henüz şikayetiniz bulunmuyor.</p></div>';
            } else {
                listDiv.innerHTML = data.sikayetler.map(complaint => createComplaintCard(complaint, false)).join('');
            }
        } else {
            listDiv.innerHTML = '<div class="error-message show">Şikayetler yüklenemedi.</div>';
        }
    } catch (error) {
        listDiv.innerHTML = '<div class="error-message show">Sunucuya bağlanılamadı.</div>';
        console.error('Load complaints error:', error);
    }
}

/**
 * Admin Şikayetlerini Yükle
 */
async function loadAdminComplaints() {
    const listDiv = document.getElementById('admin-complaints-list');
    listDiv.innerHTML = '<div class="loading">Yükleniyor...</div>';

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/complaints`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            if (data.sikayetler.length === 0) {
                listDiv.innerHTML = '<div class="empty-state"><p>Henüz şikayet bulunmuyor.</p></div>';
            } else {
                listDiv.innerHTML = data.sikayetler.map(complaint => createAdminComplaintCard(complaint)).join('');
            }
        } else {
            listDiv.innerHTML = '<div class="error-message show">Şikayetler yüklenemedi.</div>';
        }
    } catch (error) {
        listDiv.innerHTML = '<div class="error-message show">Sunucuya bağlanılamadı.</div>';
        console.error('Load admin complaints error:', error);
    }
}

/**
 * Personel Şikayetlerini Yükle
 */
async function loadPersonelComplaints() {
    const listDiv = document.getElementById('personel-complaints-list');
    listDiv.innerHTML = '<div class="loading">Yükleniyor...</div>';

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/complaints/assigned`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            if (data.sikayetler.length === 0) {
                listDiv.innerHTML = '<div class="empty-state"><p>Size atanan şikayet bulunmuyor.</p></div>';
            } else {
                listDiv.innerHTML = data.sikayetler.map(complaint => createPersonelComplaintCard(complaint)).join('');
            }
        } else {
            listDiv.innerHTML = '<div class="error-message show">Şikayetler yüklenemedi.</div>';
        }
    } catch (error) {
        listDiv.innerHTML = '<div class="error-message show">Sunucuya bağlanılamadı.</div>';
        console.error('Load personel complaints error:', error);
    }
}

/**
 * Kullanıcıları Yükle (Admin)
 */
async function loadUsers() {
    const listDiv = document.getElementById('admin-users-list');
    listDiv.innerHTML = '<div class="loading">Yükleniyor...</div>';

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/users`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            if (data.kullanicilar.length === 0) {
                listDiv.innerHTML = '<div class="empty-state"><p>Henüz kullanıcı bulunmuyor.</p></div>';
            } else {
                listDiv.innerHTML = data.kullanicilar.map(user => createUserCard(user)).join('');
            }
        } else {
            listDiv.innerHTML = '<div class="error-message show">Kullanıcılar yüklenemedi.</div>';
        }
    } catch (error) {
        listDiv.innerHTML = '<div class="error-message show">Sunucuya bağlanılamadı.</div>';
        console.error('Load users error:', error);
    }
}

/**
 * Şikayet Kartı Oluştur (Kullanıcı)
 */
function createComplaintCard(complaint, showActions = false) {
    const statusClass = `status-${complaint.durum.toLowerCase().replace(/\s/g, '-')}`;
    const date = new Date(complaint.createdAt).toLocaleDateString('tr-TR');
    
    return `
        <div class="complaint-card">
            <div class="complaint-header">
                <div class="complaint-info">
                    <h4>Şikayet #${complaint._id.slice(-6)}</h4>
                    <div class="complaint-meta">
                        <span>📅 ${date}</span>
                        ${complaint.personel ? `<span>👤 Personel: ${complaint.personel.ad} ${complaint.personel.soyad}</span>` : ''}
                    </div>
                </div>
                <span class="complaint-status ${statusClass}">${complaint.durum}</span>
            </div>
            <div class="complaint-description">${complaint.aciklama}</div>
        </div>
    `;
}

/**
 * Admin Şikayet Kartı Oluştur
 */
function createAdminComplaintCard(complaint) {
    const statusClass = `status-${complaint.durum.toLowerCase().replace(/\s/g, '-')}`;
    const date = new Date(complaint.createdAt).toLocaleDateString('tr-TR');
    const user = complaint.kullanici;
    
    return `
        <div class="complaint-card">
            <div class="complaint-header">
                <div class="complaint-info">
                    <h4>Şikayet #${complaint._id.slice(-6)}</h4>
                    <div class="complaint-meta">
                        <span>👤 ${user.ad} ${user.soyad}</span>
                        <span>📧 ${user.email}</span>
                        <span>🏠 ${user.blok} Blok, ${user.kat}. Kat, Daire ${user.daireNo}</span>
                        <span>📅 ${date}</span>
                        ${complaint.personel ? `<span>🔧 Personel: ${complaint.personel.ad} ${complaint.personel.soyad}</span>` : ''}
                    </div>
                </div>
                <span class="complaint-status ${statusClass}">${complaint.durum}</span>
            </div>
            <div class="complaint-description">${complaint.aciklama}</div>
            ${complaint.durum !== 'Tamamlandı' && !complaint.personelId ? `
                <div class="complaint-actions">
                    <select id="personel-select-${complaint._id}" class="personel-select">
                        <option value="">Personel Seçin</option>
                    </select>
                    <button class="btn btn-primary" onclick="assignPersonel('${complaint._id}')">Personele Ata</button>
                </div>
            ` : ''}
        </div>
    `;
}

/**
 * Personel Şikayet Kartı Oluştur
 */
function createPersonelComplaintCard(complaint) {
    const statusClass = `status-${complaint.durum.toLowerCase().replace(/\s/g, '-')}`;
    const date = new Date(complaint.createdAt).toLocaleDateString('tr-TR');
    const user = complaint.kullanici;
    
    return `
        <div class="complaint-card">
            <div class="complaint-header">
                <div class="complaint-info">
                    <h4>Şikayet #${complaint._id.slice(-6)}</h4>
                    <div class="complaint-meta">
                        <span>👤 ${user.ad} ${user.soyad}</span>
                        <span>🏠 ${user.blok} Blok, ${user.kat}. Kat, Daire ${user.daireNo}</span>
                        <span>📅 ${date}</span>
                    </div>
                </div>
                <span class="complaint-status ${statusClass}">${complaint.durum}</span>
            </div>
            <div class="complaint-description">${complaint.aciklama}</div>
            ${complaint.durum !== 'Tamamlandı' ? `
                <div class="complaint-actions">
                    <button class="btn btn-warning" onclick="updateComplaintStatus('${complaint._id}', 'Çözülüyor')">Çözülüyor</button>
                    <button class="btn btn-success" onclick="updateComplaintStatus('${complaint._id}', 'Tamamlandı')">Tamamlandı</button>
                </div>
            ` : ''}
        </div>
    `;
}

/**
 * Kullanıcı Kartı Oluştur
 */
function createUserCard(user) {
    const roleClass = `role-${user.rol}`;
    return `
        <div class="user-card">
            <h4>${user.ad} ${user.soyad}</h4>
            <div class="user-details">
                <span>📧 ${user.email}</span>
                <span>🏠 ${user.blok} Blok, ${user.kat}. Kat, Daire ${user.daireNo}</span>
            </div>
            <span class="user-role ${roleClass}">${user.rol}</span>
        </div>
    `;
}

/**
 * Personele Ata (Admin)
 */
async function assignPersonel(complaintId) {
    const select = document.getElementById(`personel-select-${complaintId}`);
    const personelId = select.value;
    
    if (!personelId) {
        alert('Lütfen bir personel seçin.');
        return;
    }

    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/complaints/assign/${complaintId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ personelId })
        });

        const data = await response.json();

        if (response.ok) {
            alert('Şikayet personele atandı!');
            loadAdminComplaints();
        } else {
            alert(data.mesaj || 'Atama başarısız');
        }
    } catch (error) {
        alert('Sunucuya bağlanılamadı.');
        console.error('Assign personel error:', error);
    }
}

/**
 * Şikayet Durumunu Güncelle (Personel)
 */
async function updateComplaintStatus(complaintId, durum) {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/complaints/update/${complaintId}`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${token}`
            },
            body: JSON.stringify({ durum })
        });

        const data = await response.json();

        if (response.ok) {
            alert(`Şikayet durumu "${durum}" olarak güncellendi!`);
            loadPersonelComplaints();
        } else {
            alert(data.mesaj || 'Güncelleme başarısız');
        }
    } catch (error) {
        alert('Sunucuya bağlanılamadı.');
        console.error('Update status error:', error);
    }
}

// Personel listesini yükle (Admin için)
async function loadPersonelsForSelect() {
    try {
        const token = localStorage.getItem('token');
        const response = await fetch(`${API_URL}/users`, {
            headers: {
                'Authorization': `Bearer ${token}`
            }
        });

        const data = await response.json();

        if (response.ok) {
            const personels = data.kullanicilar.filter(u => u.rol === 'personel');
            document.querySelectorAll('.personel-select').forEach(select => {
                const currentValue = select.value;
                select.innerHTML = '<option value="">Personel Seçin</option>';
                personels.forEach(personel => {
                    const option = document.createElement('option');
                    option.value = personel._id || personel.id;
                    option.textContent = `${personel.ad} ${personel.soyad}`;
                    select.appendChild(option);
                });
                if (currentValue) {
                    select.value = currentValue;
                }
            });
        }
    } catch (error) {
        console.error('Load personels error:', error);
    }
}

// Admin şikayetleri yüklendiğinde personel listesini de yükle
const originalLoadAdminComplaints = loadAdminComplaints;
loadAdminComplaints = async function() {
    await originalLoadAdminComplaints();
    // Personel listesini yükle ve select'lere ekle
    setTimeout(async () => {
        await loadPersonelsForSelect();
    }, 100);
};

