/**
 * Vercel Serverless Function
 * Express uygulamasını Vercel serverless functions olarak çalıştırır
 */

const app = require('../server');

module.exports = app;

