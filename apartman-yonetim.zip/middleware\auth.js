/**
 * JWT Authentication Middleware
 * Protected route'lar için kullanılır
 */

const jwt = require('jsonwebtoken');
const User = require('../models/User');

const auth = async (req, res, next) => {
  try {
    // Token'ı header'dan al
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
      return res.status(401).json({ mesaj: 'Token bulunamadı. Lütfen giriş yapın.' });
    }

    // Token'ı doğrula
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'gizli_anahtar');
    
    // Kullanıcıyı bul
    const user = await User.findById(decoded.userId).select('-sifre');
    
    if (!user) {
      return res.status(401).json({ mesaj: 'Kullanıcı bulunamadı.' });
    }

    // Kullanıcı bilgisini request'e ekle
    req.user = user;
    next();
  } catch (error) {
    res.status(401).json({ mesaj: 'Geçersiz token.' });
  }
};

// Rol kontrolü middleware
const checkRole = (...roles) => {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ mesaj: 'Kullanıcı bilgisi bulunamadı.' });
    }
    
    if (!roles.includes(req.user.rol)) {
      return res.status(403).json({ mesaj: 'Bu işlem için yetkiniz yok.' });
    }
    
    next();
  };
};

module.exports = { auth, checkRole };

