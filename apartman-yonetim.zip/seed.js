/**
 * Seed Script
 * İlk kullanım için test kullanıcıları oluşturur
 */

const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const User = require('./models/User');
require('dotenv').config();

async function seed() {
  try {
    // MongoDB bağlantısı
    await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/apartman-yonetim');
    console.log('✅ MongoDB bağlantısı başarılı');

    // Mevcut test kullanıcılarını sil
    await User.deleteMany({ 
      email: { $in: ['admin@test.com', 'personel@test.com', 'sakin@test.com'] } 
    });
    console.log('✅ Eski test kullanıcıları temizlendi');

    // Test kullanıcıları (şifre düz metin - User modeli otomatik hash'leyecek)
    const users = [
      {
        ad: 'Admin',
        soyad: 'Yönetici',
        email: 'admin@test.com',
        sifre: '123456', // Düz metin - User modeli pre('save') hook'u hash'leyecek
        rol: 'admin',
        blok: 'A',
        kat: '1',
        daireNo: '001'
      },
      {
        ad: 'Ahmet',
        soyad: 'Personel',
        email: 'personel@test.com',
        sifre: '123456', // Düz metin
        rol: 'personel',
        blok: 'A',
        kat: '2',
        daireNo: '002'
      },
      {
        ad: 'Mehmet',
        soyad: 'Sakin',
        email: 'sakin@test.com',
        sifre: '123456', // Düz metin
        rol: 'user',
        blok: 'B',
        kat: '3',
        daireNo: '005'
      }
    ];

    // Kullanıcıları ekle (User modeli şifreleri otomatik hash'leyecek)
    for (const userData of users) {
      const user = new User(userData);
      await user.save();
      console.log(`✅ Kullanıcı oluşturuldu: ${userData.email}`);
    }

    console.log('\n' + '='.repeat(50));
    console.log('🎉 Seed işlemi tamamlandı!\n');
    console.log('📝 Test Hesapları:');
    console.log('─'.repeat(50));
    console.log('👔 Admin   : admin@test.com     / Şifre: 123456');
    console.log('🔧 Personel: personel@test.com  / Şifre: 123456');
    console.log('👤 Sakin  : sakin@test.com     / Şifre: 123456');
    console.log('─'.repeat(50));

    process.exit(0);
  } catch (error) {
    console.error('❌ Seed hatası:', error);
    process.exit(1);
  }
}

seed();

