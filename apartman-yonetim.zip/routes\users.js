/**
 * Users Routes
 * Kullanıcı işlemleri (Sadece admin)
 */

const express = require('express');
const User = require('../models/User');
const { auth, checkRole } = require('../middleware/auth');

const router = express.Router();

/**
 * GET /api/users
 * Tüm kullanıcıları listele (Sadece admin)
 */
router.get('/', auth, checkRole('admin'), async (req, res) => {
  try {
    const users = await User.find().select('-sifre').sort({ createdAt: -1 });
    res.json({ kullanicilar: users });
  } catch (error) {
    console.error('Kullanıcı listeleme hatası:', error);
    res.status(500).json({ mesaj: 'Kullanıcılar listelenirken bir hata oluştu.', hata: error.message });
  }
});

module.exports = router;

