# 🏢 Apartman Yönetim Sistemi

Modern, temiz ve responsive bir apartman yönetim sistemi. Vanilla JavaScript, Node.js, Express ve MongoDB kullanılarak geliştirilmiştir.

## 🌟 Özellikler

### 👤 Kullanıcı (Apartman Sakini)
- ✅ Sisteme giriş yapma
- ✅ Şikayet oluşturma
- ✅ Kendi şikayetlerini görüntüleme
- ✅ Şikayet durumlarını takip etme

### 👔 Yönetici (Admin)
- ✅ Tüm kullanıcıların şikayetlerini görüntüleme
- ✅ Şikayetleri personele atama
- ✅ Kullanıcı bilgilerini görüntüleme
- ✅ Dashboard ile yönetim

### 🔧 Personel
- ✅ Atanan şikayetleri görüntüleme
- ✅ Şikayet durumunu güncelleme (Çözülüyor / Tamamlandı)
- ✅ Dashboard ile çalışma

## 🛠️ Teknoloji Stack

### Backend
- **Node.js** - Runtime
- **Express.js** - Web Framework
- **MongoDB** - Veritabanı
- **Mongoose** - ODM
- **JWT** - Kimlik Doğrulama
- **Bcryptjs** - Şifre Hashleme

### Frontend
- **HTML5** - Yapı
- **CSS3** - Styling (Modern, Responsive)
- **Vanilla JavaScript** - SPA (Single Page Application)
- **Fetch API** - HTTP İstekleri

## 📋 Gereksinimler

- Node.js (v14 veya üzeri)
- MongoDB (local veya cloud - MongoDB Atlas)
- npm veya yarn

## 🚀 Kurulum

### 1. Projeyi Klonlayın

```bash
cd apartman-yonetim
```

### 2. Bağımlılıkları Yükleyin

```bash
npm install
```

### 3. MongoDB Kurulumu

**Seçenek A: Local MongoDB**
- MongoDB'yi bilgisayarınıza kurun
- MongoDB servisinin çalıştığından emin olun

**Seçenek B: MongoDB Atlas (Cloud)**
- [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) hesabı oluşturun
- Cluster oluşturun
- Connection string'i alın

### 4. Environment Variables

`.env` dosyası oluşturun:

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/apartman-yonetim
# Veya MongoDB Atlas için:
# MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/apartman-yonetim
JWT_SECRET=apartman_yonetim_gizli_anahtar_2024
NODE_ENV=development
```

### 5. Sunucuyu Başlatın

```bash
npm run dev
```

Sunucu `http://localhost:5000` adresinde çalışacak.

### 6. Tarayıcıda Açın

```
http://localhost:5000
```

## 📡 API Endpoints

### Auth (Kimlik Doğrulama)

| Method | Endpoint | Açıklama | Auth |
|--------|----------|----------|------|
| POST | `/api/auth/register` | Kullanıcı kaydı | ❌ |
| POST | `/api/auth/login` | Kullanıcı girişi | ❌ |
| GET | `/api/auth/me` | Kullanıcı bilgileri | ✅ |

### Users (Kullanıcılar)

| Method | Endpoint | Açıklama | Auth | Rol |
|--------|----------|----------|------|-----|
| GET | `/api/users` | Tüm kullanıcıları listele | ✅ | Admin |

### Complaints (Şikayetler)

| Method | Endpoint | Açıklama | Auth | Rol |
|--------|----------|----------|------|-----|
| POST | `/api/complaints` | Yeni şikayet oluştur | ✅ | User |
| GET | `/api/complaints/my` | Kendi şikayetlerini listele | ✅ | User |
| GET | `/api/complaints` | Tüm şikayetleri listele | ✅ | Admin |
| GET | `/api/complaints/assigned` | Atanan şikayetleri listele | ✅ | Personel |
| PATCH | `/api/complaints/assign/:id` | Şikayeti personele ata | ✅ | Admin |
| PATCH | `/api/complaints/update/:id` | Şikayet durumunu güncelle | ✅ | Personel |

## 📊 Veritabanı Şeması

### User Model

```javascript
{
  ad: String,
  soyad: String,
  email: String (unique),
  sifre: String (hashed),
  rol: 'user' | 'admin' | 'personel',
  blok: String,
  kat: String,
  daireNo: String,
  createdAt: Date,
  updatedAt: Date
}
```

### Complaint Model

```javascript
{
  kullaniciId: ObjectId (ref: User),
  aciklama: String,
  durum: 'Oluşturuldu' | 'Yöneticiye iletildi' | 'Personele atandı' | 'Çözülüyor' | 'Tamamlandı',
  personelId: ObjectId (ref: User, optional),
  createdAt: Date,
  updatedAt: Date
}
```

## 🔐 Test Hesapları

İlk kullanım için manuel olarak admin kullanıcısı oluşturmanız gerekiyor:

### MongoDB'de Admin Oluşturma

MongoDB shell veya MongoDB Compass kullanarak:

```javascript
use apartman-yonetim

db.users.insertOne({
  ad: "Admin",
  soyad: "Yönetici",
  email: "admin@test.com",
  sifre: "$2a$10$...", // bcrypt hash (123456 için)
  rol: "admin",
  blok: "A",
  kat: "1",
  daireNo: "001"
})
```

Veya seed script'i kullanabilirsiniz (oluşturulacak).

## 📁 Proje Yapısı

```
apartman-yonetim/
├── models/
│   ├── User.js          # Kullanıcı modeli
│   └── Complaint.js     # Şikayet modeli
├── routes/
│   ├── auth.js          # Kimlik doğrulama routes
│   ├── users.js         # Kullanıcı routes
│   └── complaints.js    # Şikayet routes
├── middleware/
│   └── auth.js          # JWT authentication middleware
├── public/
│   ├── index.html       # Ana HTML dosyası
│   ├── styles.css       # CSS stilleri
│   └── app.js           # JavaScript (SPA)
├── server.js            # Express sunucusu
├── package.json
└── README.md
```

## 🎨 Özellikler

- ✅ Modern, temiz UI/UX
- ✅ Responsive tasarım (mobil uyumlu)
- ✅ Renkli durum göstergeleri
- ✅ Sol menülü dashboard (Admin/Personel)
- ✅ Tab yapısı (Kullanıcı paneli)
- ✅ Real-time durum güncellemeleri
- ✅ JWT ile güvenli authentication
- ✅ Rol bazlı erişim kontrolü

## 🔄 Şikayet Durumları

1. **Oluşturuldu** - Kullanıcı şikayeti oluşturdu
2. **Yöneticiye iletildi** - Otomatik olarak yöneticiye iletildi
3. **Personele atandı** - Yönetici tarafından personele atandı
4. **Çözülüyor** - Personel çözüm sürecinde
5. **Tamamlandı** - Şikayet çözüldü

## 🚀 Production Deploy

### Vercel'de Deploy

1. MongoDB Atlas kullanın (cloud database)
2. Vercel'e projeyi yükleyin
3. Environment variables ekleyin:
   - `MONGODB_URI`
   - `JWT_SECRET`
   - `NODE_ENV=production`

### Heroku'da Deploy

1. Heroku CLI ile login olun
2. `heroku create` ile proje oluşturun
3. MongoDB Atlas connection string ekleyin
4. `git push heroku main` ile deploy edin

## 📝 Notlar

- Şifreler bcrypt ile hash'lenir
- JWT token 7 gün geçerlidir
- Tüm API endpoint'leri JWT ile korunur
- Rol bazlı erişim kontrolü uygulanır

## 🐛 Sorun Giderme

### MongoDB bağlantı hatası
- MongoDB servisinin çalıştığından emin olun
- Connection string'in doğru olduğunu kontrol edin

### JWT hatası
- Token'ın geçerli olduğundan emin olun
- JWT_SECRET environment variable'ının set edildiğini kontrol edin

### CORS hatası
- Backend'de CORS middleware'inin aktif olduğundan emin olun

---

**Geliştirici:** Apartman Yönetim Sistemi Projesi

