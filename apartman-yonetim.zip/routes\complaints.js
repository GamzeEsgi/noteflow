/**
 * Complaints Routes
 * Şikayet işlemleri
 */

const express = require('express');
const Complaint = require('../models/Complaint');
const { auth, checkRole } = require('../middleware/auth');

const router = express.Router();

/**
 * POST /api/complaints
 * Yeni şikayet oluştur (Kullanıcı)
 */
router.post('/', auth, checkRole('user'), async (req, res) => {
  try {
    const { aciklama } = req.body;

    if (!aciklama || aciklama.trim().length === 0) {
      return res.status(400).json({ mesaj: 'Şikayet açıklaması gereklidir.' });
    }

    const complaint = new Complaint({
      kullaniciId: req.user._id,
      aciklama: aciklama.trim(),
      durum: 'Yöneticiye iletildi' // Otomatik olarak yöneticiye iletilir
    });

    await complaint.save();
    
    // Kullanıcı bilgisini populate et
    await complaint.populate('kullanici', 'ad soyad email blok kat daireNo');

    res.status(201).json({
      mesaj: 'Şikayet başarıyla oluşturuldu',
      sikayet: complaint
    });
  } catch (error) {
    console.error('Şikayet oluşturma hatası:', error);
    res.status(500).json({ mesaj: 'Şikayet oluşturulurken bir hata oluştu.', hata: error.message });
  }
});

/**
 * GET /api/complaints/my
 * Kullanıcının kendi şikayetlerini listele
 */
router.get('/my', auth, checkRole('user'), async (req, res) => {
  try {
    const complaints = await Complaint.find({ kullaniciId: req.user._id })
      .populate('personel', 'ad soyad')
      .sort({ createdAt: -1 });
    
    res.json({ sikayetler: complaints });
  } catch (error) {
    console.error('Şikayet listeleme hatası:', error);
    res.status(500).json({ mesaj: 'Şikayetler listelenirken bir hata oluştu.', hata: error.message });
  }
});

/**
 * GET /api/complaints
 * Tüm şikayetleri listele (Admin)
 */
router.get('/', auth, checkRole('admin'), async (req, res) => {
  try {
    const complaints = await Complaint.find()
      .populate('kullanici', 'ad soyad email blok kat daireNo')
      .populate('personel', 'ad soyad')
      .sort({ createdAt: -1 });
    
    res.json({ sikayetler: complaints });
  } catch (error) {
    console.error('Şikayet listeleme hatası:', error);
    res.status(500).json({ mesaj: 'Şikayetler listelenirken bir hata oluştu.', hata: error.message });
  }
});

/**
 * PATCH /api/complaints/assign/:id
 * Şikayeti personele ata (Admin)
 */
router.patch('/assign/:id', auth, checkRole('admin'), async (req, res) => {
  try {
    const { personelId } = req.body;

    if (!personelId) {
      return res.status(400).json({ mesaj: 'Personel ID gereklidir.' });
    }

    // Personelin gerçekten personel rolünde olduğunu kontrol et
    const User = require('../models/User');
    const personel = await User.findById(personelId);
    
    if (!personel || personel.rol !== 'personel') {
      return res.status(400).json({ mesaj: 'Geçersiz personel ID.' });
    }

    const complaint = await Complaint.findByIdAndUpdate(
      req.params.id,
      {
        personelId,
        durum: 'Personele atandı'
      },
      { new: true }
    )
      .populate('kullanici', 'ad soyad email blok kat daireNo')
      .populate('personel', 'ad soyad');

    if (!complaint) {
      return res.status(404).json({ mesaj: 'Şikayet bulunamadı.' });
    }

    res.json({
      mesaj: 'Şikayet personele atandı',
      sikayet: complaint
    });
  } catch (error) {
    console.error('Şikayet atama hatası:', error);
    res.status(500).json({ mesaj: 'Şikayet atanırken bir hata oluştu.', hata: error.message });
  }
});

/**
 * PATCH /api/complaints/update/:id
 * Şikayet durumunu güncelle (Personel)
 */
router.patch('/update/:id', auth, checkRole('personel'), async (req, res) => {
  try {
    const { durum } = req.body;

    const allowedStatuses = ['Çözülüyor', 'Tamamlandı'];
    if (!durum || !allowedStatuses.includes(durum)) {
      return res.status(400).json({ 
        mesaj: 'Geçersiz durum. Sadece "Çözülüyor" veya "Tamamlandı" seçilebilir.' 
      });
    }

    // Şikayetin bu personele atanmış olduğunu kontrol et
    const complaint = await Complaint.findById(req.params.id);
    
    if (!complaint) {
      return res.status(404).json({ mesaj: 'Şikayet bulunamadı.' });
    }

    if (complaint.personelId?.toString() !== req.user._id.toString()) {
      return res.status(403).json({ mesaj: 'Bu şikayet size atanmamış.' });
    }

    const updatedComplaint = await Complaint.findByIdAndUpdate(
      req.params.id,
      { durum },
      { new: true }
    )
      .populate('kullanici', 'ad soyad email blok kat daireNo')
      .populate('personel', 'ad soyad');

    res.json({
      mesaj: 'Şikayet durumu güncellendi',
      sikayet: updatedComplaint
    });
  } catch (error) {
    console.error('Şikayet güncelleme hatası:', error);
    res.status(500).json({ mesaj: 'Şikayet güncellenirken bir hata oluştu.', hata: error.message });
  }
});

/**
 * GET /api/complaints/assigned
 * Personele atanan şikayetleri listele
 */
router.get('/assigned', auth, checkRole('personel'), async (req, res) => {
  try {
    const complaints = await Complaint.find({ personelId: req.user._id })
      .populate('kullanici', 'ad soyad email blok kat daireNo')
      .sort({ createdAt: -1 });
    
    res.json({ sikayetler: complaints });
  } catch (error) {
    console.error('Şikayet listeleme hatası:', error);
    res.status(500).json({ mesaj: 'Şikayetler listelenirken bir hata oluştu.', hata: error.message });
  }
});

module.exports = router;

